# Versions

A library providing base classes with the functionality to create, update and query versioned data. Uses MongoDB and Elasticsearch.

**This project is currently under active development.**
